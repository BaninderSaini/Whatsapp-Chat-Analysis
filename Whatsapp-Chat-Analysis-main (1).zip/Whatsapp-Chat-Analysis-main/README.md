# Whatsapp-Chat-Analysis
This application does WhatsApp chat analysis of 12 Hour format exported chat by
plotting graphs about most used words, emojis,active users etc. It is made in python
The framework used is streamlit.
